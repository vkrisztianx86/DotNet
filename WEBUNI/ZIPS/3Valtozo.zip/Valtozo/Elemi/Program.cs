﻿


int x = 11;

char c = 'a';

bool b = false;

double d = 2.1;

string s = "alma";

Console.WriteLine(x);
Console.WriteLine(c);
Console.WriteLine(b);
Console.WriteLine(d);
Console.WriteLine(s);

Console.WriteLine(sizeof(bool));

