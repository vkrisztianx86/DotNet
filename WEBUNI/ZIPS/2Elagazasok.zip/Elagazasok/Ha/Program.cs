﻿int x = 10;

if (x<10)
{
    Console.WriteLine("kevés");
}
else
{
    Console.WriteLine("sok");
}

int y = x < 10 ? 0 : 1;

Console.WriteLine(y);
