﻿namespace Autonyilvantarto
{
    public enum AutoEnum
    {
        Fiat,
        Ford
    }
}
