﻿

using StatStrHlp;

string s = "asdfasdfasdf";
Console.WriteLine(StrHelper.Hullamos(s));

